import { useState } from 'react';
import { CalendarDays } from 'lucide-react';
import { useFetch } from '../api.js';
import { PageHeader, Loader, ErrorBox, Empty, catBadge, fmtDate } from '../components/ui.jsx';

const CATS = ['All', 'Exam', 'Holiday', 'Event', 'General'];

export default function Notices() {
  const { data, error } = useFetch('/notices');
  const [cat, setCat] = useState('All');
  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loader />;
  const list = data.filter((n) => cat === 'All' || n.category === cat);
  return (
    <>
      <PageHeader title="Notice Board" subtitle="Exam notices, holidays, events and announcements" />
      <div className="mb-5 flex flex-wrap gap-2">
        {CATS.map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${cat === c ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow' : 'bg-white text-slate-600 hover:bg-slate-100'}`}>{c}</button>
        ))}
      </div>
      {list.length === 0 ? <Empty text="No notices in this category." /> : (
        <div className="grid gap-4 md:grid-cols-2">
          {list.map((n) => (
            <div key={n.id} className="card transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="mb-2 flex items-center justify-between">
                <span className={`badge ${catBadge[n.category] || catBadge.General}`}>{n.category}</span>
                <span className="flex items-center gap-1 text-xs text-slate-400"><CalendarDays className="h-3.5 w-3.5" />{fmtDate(n.notice_date)}</span>
              </div>
              <h3 className="font-bold text-navy-900">{n.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-slate-600">{n.content}</p>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
