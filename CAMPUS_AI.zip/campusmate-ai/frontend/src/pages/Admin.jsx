import { useEffect, useState } from 'react';
import { LogOut, Pencil, Plus, Trash2, Upload } from 'lucide-react';
import { api, getToken, useFetch } from '../api.js';
import { PageHeader, ErrorBox, Loader, fmtDate } from '../components/ui.jsx';

const today = new Date().toISOString().slice(0, 10);
const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const SEMS = ['1', '2', '3', '4', '5', '6', '7', '8'];

const TABS = {
  Notices: {
    resource: 'notices', cols: ['title', 'category', 'notice_date'],
    fields: [
      { key: 'title', label: 'Title' },
      { key: 'category', label: 'Category', type: 'select', options: ['General', 'Exam', 'Holiday', 'Event'], default: 'General' },
      { key: 'notice_date', label: 'Date', type: 'date', default: today },
      { key: 'content', label: 'Details', type: 'textarea' },
    ],
  },
  Faculty: {
    resource: 'faculty', cols: ['name', 'department', 'designation', 'email'],
    fields: [
      { key: 'name', label: 'Name' },
      { key: 'department', label: 'Department', type: 'dept' },
      { key: 'designation', label: 'Designation' },
      { key: 'email', label: 'Official email' },
      { key: 'phone', label: 'Phone' },
    ],
  },
  Timetable: {
    resource: 'timetable', cols: ['department', 'semester', 'day', 'start_time', 'subject'],
    fields: [
      { key: 'department', label: 'Department', type: 'dept' },
      { key: 'semester', label: 'Semester', type: 'select', options: SEMS, default: '1' },
      { key: 'day', label: 'Day', type: 'select', options: DAYS, default: 'Monday' },
      { key: 'start_time', label: 'Start time', type: 'time' },
      { key: 'end_time', label: 'End time', type: 'time' },
      { key: 'subject', label: 'Subject' },
      { key: 'room', label: 'Room' },
      { key: 'faculty', label: 'Faculty' },
    ],
  },
  Departments: {
    resource: 'departments', cols: ['name', 'courses'],
    fields: [
      { key: 'name', label: 'Department name' },
      { key: 'courses', label: 'Courses (comma separated)' },
      { key: 'description', label: 'Description', type: 'textarea' },
    ],
  },
};

function Field({ f, value, onChange, depts }) {
  const common = { className: 'input', value, onChange: (e) => onChange(e.target.value) };
  let input;
  if (f.type === 'textarea') input = <textarea rows={3} {...common} />;
  else if (f.type === 'select') input = <select {...common}>{f.options.map((o) => <option key={o}>{o}</option>)}</select>;
  else if (f.type === 'dept') {
    const names = depts.map((d) => d.name);
    if (value && !names.includes(value)) names.push(value);
    input = <select {...common}><option value="">Select department</option>{names.map((n) => <option key={n}>{n}</option>)}</select>;
  } else input = <input type={f.type || 'text'} {...common} />;
  return (
    <label className={`block text-xs font-semibold text-slate-500 ${f.type === 'textarea' ? 'sm:col-span-2' : ''}`}>
      <span className="mb-1 block">{f.label}</span>{input}
    </label>
  );
}

function Crud({ tab }) {
  const { resource, fields, cols } = tab;
  const { data, reload } = useFetch('/' + resource);
  const depts = useFetch('/departments').data || [];
  const blank = Object.fromEntries(fields.map((f) => [f.key, f.default ?? '']));
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [msg, setMsg] = useState('');

  useEffect(() => { setForm(blank); setEditId(null); setMsg(''); }, [resource]); // eslint-disable-line

  const submit = async (e) => {
    e.preventDefault();
    setMsg('');
    try {
      if (editId) await api.put(`/${resource}/${editId}`, form);
      else await api.post('/' + resource, form);
      setForm(blank); setEditId(null); reload();
    } catch (err) { setMsg(err.message); }
  };
  const remove = async (id) => {
    if (!confirm('Delete this item?')) return;
    try { await api.del(`/${resource}/${id}`); reload(); } catch (err) { setMsg(err.message); }
  };
  const edit = (item) => { setEditId(item.id); setForm(Object.fromEntries(fields.map((f) => [f.key, item[f.key] ?? '']))); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  return (
    <div className="space-y-5">
      <form onSubmit={submit} className="card">
        <h3 className="mb-4 font-bold text-navy-900">{editId ? 'Edit item' : 'Add new'}</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          {fields.map((f) => <Field key={f.key} f={f} depts={depts} value={form[f.key]} onChange={(v) => setForm({ ...form, [f.key]: v })} />)}
        </div>
        <div className="mt-4 flex items-center gap-2">
          <button className="btn-primary"><Plus className="h-4 w-4" />{editId ? 'Save changes' : 'Add'}</button>
          {editId && <button type="button" className="btn-ghost" onClick={() => { setEditId(null); setForm(blank); }}>Cancel</button>}
          <span className="text-sm text-red-600">{msg}</span>
        </div>
      </form>
      <div className="card overflow-x-auto !p-0">
        {!data ? <Loader /> : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500">
              <tr>{cols.map((c) => <th key={c} className="px-4 py-3">{c.replace('_', ' ')}</th>)}<th className="px-4 py-3 text-right">Actions</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50">
                  {cols.map((c) => <td key={c} className="px-4 py-3">{item[c]}</td>)}
                  <td className="whitespace-nowrap px-4 py-3 text-right">
                    <button className="btn-ghost !px-2.5 !py-1.5" onClick={() => edit(item)}><Pencil className="h-4 w-4" /></button>{' '}
                    <button className="btn-danger !px-2.5 !py-1.5" onClick={() => remove(item.id)}><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
              {data.length === 0 && <tr><td className="px-4 py-8 text-center text-slate-400" colSpan={cols.length + 1}>Nothing here yet.</td></tr>}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function Documents() {
  const { data, reload } = useFetch('/documents');
  const depts = useFetch('/departments').data || [];
  const [form, setForm] = useState({ title: '', category: 'General', department: 'All', semester: '' });
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState({ text: '', ok: false });
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!file) return setMsg({ text: 'Choose a PDF or text file first.', ok: false });
    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => fd.append(k, v));
    fd.append('file', file);
    setBusy(true); setMsg({ text: '', ok: false });
    try {
      const r = await api.upload('/documents', fd);
      setMsg({ text: r.warning || `Uploaded and indexed (${r.chunks} text sections).`, ok: !r.warning });
      setFile(null); e.target.reset(); setForm({ ...form, title: '' }); reload();
    } catch (err) { setMsg({ text: err.message, ok: false }); } finally { setBusy(false); }
  };
  const remove = async (id) => {
    if (!confirm('Delete this document? The AI will no longer use it.')) return;
    await api.del('/documents/' + id); reload();
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="space-y-5">
      <form onSubmit={submit} className="card">
        <h3 className="mb-1 font-bold text-navy-900">Upload document</h3>
        <p className="mb-4 text-xs text-slate-500">PDF/TXT files are read automatically and become the AI's knowledge. "General" = college rules/handbooks (hidden from Study Materials).</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-xs font-semibold text-slate-500"><span className="mb-1 block">Title</span><input className="input" value={form.title} onChange={set('title')} placeholder="e.g. CSE Sem 3 Syllabus" /></label>
          <label className="block text-xs font-semibold text-slate-500"><span className="mb-1 block">Category</span>
            <select className="input" value={form.category} onChange={set('category')}>{['General', 'Notes', 'Syllabus', 'Previous Papers'].map((c) => <option key={c}>{c}</option>)}</select></label>
          <label className="block text-xs font-semibold text-slate-500"><span className="mb-1 block">Department</span>
            <select className="input" value={form.department} onChange={set('department')}><option>All</option>{depts.map((d) => <option key={d.id}>{d.name}</option>)}</select></label>
          <label className="block text-xs font-semibold text-slate-500"><span className="mb-1 block">Semester (optional)</span>
            <select className="input" value={form.semester} onChange={set('semester')}><option value="">-</option>{SEMS.map((s) => <option key={s}>{s}</option>)}</select></label>
          <label className="block text-xs font-semibold text-slate-500 sm:col-span-2"><span className="mb-1 block">File (PDF, TXT, MD - max 25 MB)</span>
            <input type="file" accept=".pdf,.txt,.md" className="input" onChange={(e) => setFile(e.target.files[0])} /></label>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <button className="btn-primary" disabled={busy}><Upload className="h-4 w-4" />{busy ? 'Uploading...' : 'Upload'}</button>
          <span className={`text-sm ${msg.ok ? 'text-emerald-600' : 'text-red-600'}`}>{msg.text}</span>
        </div>
      </form>
      <div className="card overflow-x-auto !p-0">
        {!data ? <Loader /> : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase text-slate-500"><tr><th className="px-4 py-3">Title</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Department</th><th className="px-4 py-3">Uploaded</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {data.map((d) => (
                <tr key={d.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium">{d.title}</td><td className="px-4 py-3">{d.category}</td><td className="px-4 py-3">{d.department}</td><td className="px-4 py-3">{fmtDate(d.uploaded_at)}</td>
                  <td className="px-4 py-3 text-right"><button className="btn-danger !px-2.5 !py-1.5" onClick={() => remove(d.id)}><Trash2 className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function CollegeInfo() {
  const { data } = useFetch('/college');
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState('');
  useEffect(() => { if (data) setForm(data); }, [data]);
  if (!form) return <Loader />;
  const F = [['name', 'College name'], ['address', 'Address'], ['phone', 'Phone'], ['email', 'Email'], ['website', 'Website'], ['opening_time', 'Opening time'], ['closing_time', 'Closing time']];
  const save = async (e) => {
    e.preventDefault();
    try { await api.put('/college', form); setMsg('Saved!'); } catch (err) { setMsg(err.message); }
  };
  return (
    <form onSubmit={save} className="card">
      <div className="grid gap-3 sm:grid-cols-2">
        {F.map(([k, label]) => (
          <label key={k} className="block text-xs font-semibold text-slate-500"><span className="mb-1 block">{label}</span>
            <input className="input" value={form[k] || ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></label>
        ))}
        <label className="block text-xs font-semibold text-slate-500 sm:col-span-2"><span className="mb-1 block">Admission information</span>
          <textarea rows={5} className="input" value={form.admission_info || ''} onChange={(e) => setForm({ ...form, admission_info: e.target.value })} /></label>
      </div>
      <div className="mt-4 flex items-center gap-3"><button className="btn-primary">Save changes</button><span className="text-sm text-emerald-600">{msg}</span></div>
    </form>
  );
}

function Login({ onLogin }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [err, setErr] = useState('');
  const submit = async (e) => {
    e.preventDefault();
    try {
      const r = await api.post('/admin/login', { username: u, password: p });
      localStorage.setItem('cm_token', r.token);
      onLogin();
    } catch (e2) { setErr(e2.message); }
  };
  return (
    <div className="mx-auto mt-10 max-w-sm">
      <form onSubmit={submit} className="card space-y-4">
        <h2 className="text-xl font-extrabold text-navy-900">Admin Login</h2>
        <input className="input" placeholder="Username" value={u} onChange={(e) => setU(e.target.value)} autoFocus />
        <input className="input" type="password" placeholder="Password" value={p} onChange={(e) => setP(e.target.value)} />
        <ErrorBox message={err} />
        <button className="btn-primary w-full">Sign in</button>
      </form>
    </div>
  );
}

export default function Admin() {
  const [authed, setAuthed] = useState(!!getToken());
  const [tab, setTab] = useState('Notices');
  useEffect(() => {
    const h = () => setAuthed(!!getToken());
    window.addEventListener('cm-auth', h);
    return () => window.removeEventListener('cm-auth', h);
  }, []);
  if (!authed) return <><PageHeader title="Admin Dashboard" subtitle="Sign in to manage college data" /><Login onLogin={() => setAuthed(true)} /></>;
  const names = [...Object.keys(TABS), 'Documents', 'College Info'];
  return (
    <>
      <PageHeader title="Admin Dashboard" subtitle="Manage notices, documents, faculty and timetable">
        <button className="btn-ghost" onClick={() => { localStorage.removeItem('cm_token'); setAuthed(false); }}><LogOut className="h-4 w-4" />Logout</button>
      </PageHeader>
      <div className="mb-5 flex flex-wrap gap-2">
        {names.map((n) => (
          <button key={n} onClick={() => setTab(n)} className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${tab === n ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow' : 'bg-white text-slate-600 hover:bg-slate-100'}`}>{n}</button>
        ))}
      </div>
      {TABS[tab] ? <Crud key={tab} tab={TABS[tab]} /> : tab === 'Documents' ? <Documents /> : <CollegeInfo />}
    </>
  );
}
