import { useEffect, useRef, useState } from 'react';
import { FileText, Send, Sparkles, User } from 'lucide-react';
import { api } from '../api.js';
import { PageHeader } from '../components/ui.jsx';

const SUGGESTED = [
  'What are the college timings?',
  'How can I apply for admission?',
  'What is the attendance requirement?',
  'Which departments and courses are available?',
  'Are there any upcoming exam notices?',
  'Who is the Head of Computer Science?',
];

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, loading]);

  const send = async (text) => {
    const q = (text ?? input).trim();
    if (!q || loading) return;
    const history = messages.filter((m) => !m.error).map((m) => ({ role: m.role, content: m.content }));
    setMessages((m) => [...m, { role: 'user', content: q }]);
    setInput('');
    setLoading(true);
    try {
      const r = await api.post('/chat', { message: q, history });
      setMessages((m) => [...m, { role: 'assistant', content: r.answer, sources: r.sources }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'assistant', content: e.message, error: true }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-7rem)] flex-col lg:h-[calc(100vh-4rem)]">
      <PageHeader title="AI Assistant" subtitle="Answers are based only on official college documents and data." />
      <div className="card flex min-h-0 flex-1 flex-col !p-0">
        <div className="flex-1 space-y-4 overflow-y-auto p-4 sm:p-6">
          {messages.length === 0 && (
            <div className="grid h-full place-items-center text-center">
              <div>
                <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg shadow-purple-500/30"><Sparkles /></div>
                <h2 className="text-lg font-bold text-navy-900">Hi! I'm CampusMate AI</h2>
                <p className="mb-5 text-sm text-slate-500">Try one of these questions:</p>
                <div className="flex max-w-xl flex-wrap justify-center gap-2">
                  {SUGGESTED.map((s) => (
                    <button key={s} onClick={() => send(s)} className="rounded-full border border-indigo-200 bg-indigo-50 px-4 py-2 text-sm font-medium text-indigo-700 transition hover:bg-indigo-100 active:scale-95">{s}</button>
                  ))}
                </div>
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex animate-fadeUp gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-white ${m.role === 'user' ? 'bg-navy-800' : 'bg-gradient-to-br from-blue-500 to-purple-600'}`}>
                {m.role === 'user' ? <User className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
              </div>
              <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === 'user' ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white' : m.error ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-800'}`}>
                <p className="whitespace-pre-wrap">{m.content}</p>
                {m.sources?.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2 border-t border-slate-200 pt-2">
                    {m.sources.map((s) => {
                      const cls = 'flex items-center gap-1 rounded-full bg-white px-2.5 py-1 text-xs font-medium text-indigo-700 shadow-sm';
                      const body = <><FileText className="h-3 w-3" />[{s.n}] {s.source}</>;
                      return s.doc_id
                        ? <a key={s.n} href={`/api/documents/${s.doc_id}/download`} target="_blank" rel="noreferrer" className={cls + ' hover:bg-indigo-50'}>{body}</a>
                        : <span key={s.n} className={cls}>{body}</span>;
                    })}
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-3">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white"><Sparkles className="h-4 w-4" /></div>
              <div className="flex items-center gap-1 rounded-2xl bg-slate-100 px-4 py-3">
                {[0, 1, 2].map((d) => <span key={d} className="h-2 w-2 animate-bounce rounded-full bg-indigo-400" style={{ animationDelay: `${d * 0.15}s` }} />)}
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 border-t border-slate-100 p-3 sm:p-4">
          <input className="input" placeholder="Ask about timings, admission, exams, faculty..." value={input} onChange={(e) => setInput(e.target.value)} />
          <button className="btn-primary" disabled={loading || !input.trim()}><Send className="h-4 w-4" /><span className="hidden sm:inline">Send</span></button>
        </form>
      </div>
    </div>
  );
}
