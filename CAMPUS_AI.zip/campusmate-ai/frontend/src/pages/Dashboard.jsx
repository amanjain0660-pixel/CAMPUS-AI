import { Link } from 'react-router-dom';
import { ArrowRight, Clock, Mail, MapPin, MessageSquare, Phone, Sparkles } from 'lucide-react';
import { useFetch } from '../api.js';
import { PageHeader, Loader, ErrorBox, catBadge, fmtDate } from '../components/ui.jsx';

export default function Dashboard() {
  const college = useFetch('/college');
  const notices = useFetch('/notices');
  const depts = useFetch('/departments');
  const c = college.data;
  if (college.error) return <ErrorBox message={college.error + ' - is the backend running on port 5000?'} />;
  if (!c) return <Loader />;
  return (
    <>
      <div className="relative mb-6 overflow-hidden rounded-3xl bg-gradient-to-br from-navy-900 via-navy-800 to-indigo-700 p-6 text-white shadow-xl sm:p-8">
        <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-purple-500/30 blur-3xl" />
        <p className="text-sm font-medium text-indigo-200">Welcome to</p>
        <h1 className="mt-1 text-2xl font-extrabold sm:text-4xl">{c.name}</h1>
        <p className="mt-2 max-w-xl text-sm text-indigo-100">Ask anything about timings, admissions, notices, timetables and faculty - answered from official college documents.</p>
        <Link to="/chat" className="btn mt-5 bg-white text-indigo-700 hover:bg-indigo-50"><Sparkles className="h-4 w-4" /> Ask CampusMate AI</Link>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <div className="card lg:col-span-1">
          <h2 className="mb-4 font-bold text-navy-900">College Information</h2>
          <ul className="space-y-3 text-sm text-slate-600">
            <li className="flex gap-3"><MapPin className="h-4 w-4 shrink-0 text-indigo-500" />{c.address}</li>
            <li className="flex gap-3"><Clock className="h-4 w-4 shrink-0 text-indigo-500" />Opens {c.opening_time} - Closes {c.closing_time}</li>
            <li className="flex gap-3"><Phone className="h-4 w-4 shrink-0 text-indigo-500" />{c.phone}</li>
            <li className="flex gap-3"><Mail className="h-4 w-4 shrink-0 text-indigo-500" />{c.email}</li>
          </ul>
          <h3 className="mb-1 mt-5 text-sm font-bold text-navy-900">Admissions</h3>
          <p className="text-sm leading-relaxed text-slate-600">{c.admission_info}</p>
        </div>
        <div className="space-y-5 lg:col-span-2">
          <div className="card">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-bold text-navy-900">Latest Notices</h2>
              <Link to="/notices" className="flex items-center gap-1 text-sm font-semibold text-indigo-600">View all <ArrowRight className="h-4 w-4" /></Link>
            </div>
            <div className="divide-y divide-slate-100">
              {(notices.data || []).slice(0, 4).map((n) => (
                <div key={n.id} className="flex items-start justify-between gap-3 py-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{n.title}</p>
                    <p className="text-xs text-slate-400">{fmtDate(n.notice_date)}</p>
                  </div>
                  <span className={`badge ${catBadge[n.category] || catBadge.General}`}>{n.category}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h2 className="mb-3 font-bold text-navy-900">Departments & Courses</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {(depts.data || []).map((d) => (
                <div key={d.id} className="rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 p-4">
                  <p className="text-sm font-bold text-navy-900">{d.name}</p>
                  <p className="mt-0.5 text-xs font-medium text-indigo-600">{d.courses}</p>
                  <p className="mt-1 text-xs text-slate-500">{d.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
