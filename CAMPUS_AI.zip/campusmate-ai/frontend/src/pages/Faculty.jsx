import { useState } from 'react';
import { Mail, Phone, Search } from 'lucide-react';
import { useFetch } from '../api.js';
import { PageHeader, Loader, ErrorBox, Empty } from '../components/ui.jsx';

export default function Faculty() {
  const { data, error } = useFetch('/faculty');
  const [q, setQ] = useState('');
  const [dept, setDept] = useState('All');
  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loader />;
  const depts = ['All', ...new Set(data.map((f) => f.department))];
  const list = data.filter((f) => (dept === 'All' || f.department === dept) && (f.name + f.designation).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title="Faculty Directory" subtitle="Official faculty contact information">
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input className="input !pl-9" placeholder="Search faculty" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <select className="input !w-auto" value={dept} onChange={(e) => setDept(e.target.value)}>{depts.map((d) => <option key={d}>{d}</option>)}</select>
        </div>
      </PageHeader>
      {list.length === 0 ? <Empty text="No faculty found." /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((f) => (
            <div key={f.id} className="card transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="mb-3 grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-lg font-bold text-white">
                {f.name.replace(/^(Dr|Mr|Ms|Mrs|Prof)\.?\s+/i, '').charAt(0)}
              </div>
              <h3 className="font-bold text-navy-900">{f.name}</h3>
              <p className="text-sm font-medium text-indigo-600">{f.designation}</p>
              <p className="mb-3 text-xs text-slate-500">{f.department}</p>
              {f.email && <a href={`mailto:${f.email}`} className="flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600"><Mail className="h-4 w-4" />{f.email}</a>}
              {f.phone && <a href={`tel:${f.phone}`} className="mt-1 flex items-center gap-2 text-sm text-slate-600 hover:text-indigo-600"><Phone className="h-4 w-4" />{f.phone}</a>}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
