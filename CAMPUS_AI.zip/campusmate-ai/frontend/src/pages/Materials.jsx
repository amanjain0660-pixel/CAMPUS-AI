import { useState } from 'react';
import { Download, FileText, Search } from 'lucide-react';
import { useFetch } from '../api.js';
import { PageHeader, Loader, ErrorBox, Empty, fmtDate } from '../components/ui.jsx';

const CATS = ['All', 'Notes', 'Syllabus', 'Previous Papers'];

export default function Materials() {
  const { data, error } = useFetch('/documents');
  const [cat, setCat] = useState('All');
  const [q, setQ] = useState('');
  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loader />;
  const list = data.filter((d) => d.category !== 'General' && (cat === 'All' || d.category === cat) && (d.title + d.department).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title="Study Materials" subtitle="Notes, syllabus and previous-year papers">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          <input className="input !pl-9" placeholder="Search materials" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </PageHeader>
      <div className="mb-5 flex flex-wrap gap-2">
        {CATS.map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${cat === c ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow' : 'bg-white text-slate-600 hover:bg-slate-100'}`}>{c}</button>
        ))}
      </div>
      {list.length === 0 ? <Empty text="No study materials uploaded yet. Admins can add them from the Admin panel." /> : (
        <div className="grid gap-4 md:grid-cols-2">
          {list.map((d) => (
            <div key={d.id} className="card flex items-center gap-4">
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-blue-100 to-purple-100 text-indigo-600"><FileText /></div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold text-navy-900">{d.title}</p>
                <p className="text-xs text-slate-500">{d.category} - {d.department}{d.semester && ` - Sem ${d.semester}`} - {fmtDate(d.uploaded_at)}</p>
              </div>
              <a className="btn-primary !px-3" href={`/api/documents/${d.id}/download`} target="_blank" rel="noreferrer"><Download className="h-4 w-4" /></a>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
