import { useEffect, useState } from 'react';
import { useFetch } from '../api.js';
import { PageHeader, Loader, ErrorBox, Empty } from '../components/ui.jsx';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function Timetable() {
  const { data, error } = useFetch('/timetable');
  const [dept, setDept] = useState('');
  const [sem, setSem] = useState('');
  const depts = [...new Set((data || []).map((t) => t.department))];
  const sems = [...new Set((data || []).filter((t) => t.department === dept).map((t) => t.semester))].sort((a, b) => a - b);
  useEffect(() => { if (depts.length && !depts.includes(dept)) setDept(depts[0]); }, [data]); // eslint-disable-line
  useEffect(() => { if (sems.length && !sems.includes(sem)) setSem(sems[0]); }, [dept, data]); // eslint-disable-line
  if (error) return <ErrorBox message={error} />;
  if (!data) return <Loader />;
  const slots = data.filter((t) => t.department === dept && t.semester === sem);
  return (
    <>
      <PageHeader title="Timetable" subtitle="Class schedules by department and semester">
        <div className="flex gap-2">
          <select className="input !w-auto" value={dept} onChange={(e) => setDept(e.target.value)}>{depts.map((d) => <option key={d}>{d}</option>)}</select>
          <select className="input !w-auto" value={sem} onChange={(e) => setSem(e.target.value)}>{sems.map((s) => <option key={s} value={s}>Semester {s}</option>)}</select>
        </div>
      </PageHeader>
      {slots.length === 0 ? <Empty text="No timetable has been added yet." /> : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {DAYS.map((day) => {
            const items = slots.filter((s) => s.day === day);
            return (
              <div key={day} className="card">
                <h3 className="mb-3 font-bold text-navy-900">{day}</h3>
                {items.length === 0 ? <p className="text-sm text-slate-400">No classes</p> : (
                  <div className="space-y-2">
                    {items.map((s) => (
                      <div key={s.id} className="rounded-xl border-l-4 border-indigo-500 bg-gradient-to-r from-blue-50 to-purple-50 p-3">
                        <p className="text-xs font-semibold text-indigo-600">{s.start_time} - {s.end_time}</p>
                        <p className="text-sm font-bold text-navy-900">{s.subject}</p>
                        <p className="text-xs text-slate-500">{s.room}{s.faculty && ` - ${s.faculty}`}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
