import { Loader2 } from 'lucide-react';

export const PageHeader = ({ title, subtitle, children }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div>
      <h1 className="text-2xl font-extrabold tracking-tight text-navy-900 sm:text-3xl">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
    </div>
    {children}
  </div>
);

export const Loader = () => (
  <div className="flex items-center justify-center py-16 text-indigo-500">
    <Loader2 className="h-6 w-6 animate-spin" />
  </div>
);

export const ErrorBox = ({ message }) =>
  message ? <div className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-600">{message}</div> : null;

export const Empty = ({ text }) => (
  <div className="card py-12 text-center text-sm text-slate-400">{text}</div>
);

export const catBadge = {
  Exam: 'bg-rose-100 text-rose-700',
  Holiday: 'bg-emerald-100 text-emerald-700',
  Event: 'bg-violet-100 text-violet-700',
  General: 'bg-blue-100 text-blue-700',
};

export const fmtDate = (d) =>
  d ? new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '';
