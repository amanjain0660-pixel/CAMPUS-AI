import { useState } from 'react';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import { BookOpen, Bell, CalendarDays, GraduationCap, LayoutDashboard, Menu, MessageSquare, Shield, Users, X } from 'lucide-react';
import Dashboard from './pages/Dashboard.jsx';
import Chat from './pages/Chat.jsx';
import Notices from './pages/Notices.jsx';
import Timetable from './pages/Timetable.jsx';
import Faculty from './pages/Faculty.jsx';
import Materials from './pages/Materials.jsx';
import Admin from './pages/Admin.jsx';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/chat', label: 'AI Assistant', icon: MessageSquare },
  { to: '/notices', label: 'Notice Board', icon: Bell },
  { to: '/timetable', label: 'Timetable', icon: CalendarDays },
  { to: '/faculty', label: 'Faculty', icon: Users },
  { to: '/materials', label: 'Study Materials', icon: BookOpen },
  { to: '/admin', label: 'Admin', icon: Shield },
];

function Layout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex min-h-screen">
      {open && <div className="fixed inset-0 z-30 bg-navy-950/50 backdrop-blur-sm lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-gradient-to-b from-navy-900 to-navy-950 p-5 text-white transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-purple-500/30">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="font-extrabold">CampusMate</div>
              <div className="text-xs text-indigo-300">AI Assistant</div>
            </div>
          </div>
          <button className="lg:hidden" onClick={() => setOpen(false)}><X className="h-5 w-5" /></button>
        </div>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
              className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${isActive ? 'bg-gradient-to-r from-blue-600/80 to-purple-600/80 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-300 hover:bg-white/10'}`}>
              <Icon className="h-[18px] w-[18px]" /> {label}
            </NavLink>
          ))}
        </nav>
        <p className="text-xs text-slate-400">Answers come only from official college data.</p>
      </aside>
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur lg:hidden">
          <button onClick={() => setOpen(true)}><Menu className="h-6 w-6 text-navy-900" /></button>
          <span className="font-extrabold text-navy-900">CampusMate AI</span>
        </header>
        <main className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/notices" element={<Notices />} />
            <Route path="/timetable" element={<Timetable />} />
            <Route path="/faculty" element={<Faculty />} />
            <Route path="/materials" element={<Materials />} />
            <Route path="/admin" element={<Admin />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  );
}
