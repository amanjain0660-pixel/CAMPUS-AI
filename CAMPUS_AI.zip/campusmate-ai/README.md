# CampusMate AI - Smart College Information Assistant

React + Tailwind frontend, Flask + SQLite backend, Anthropic Claude for answers.
The AI only answers from your college data (database + uploaded PDF/TXT files) and cites its sources.

## Folder structure
```
campusmate-ai/
├── backend/
│   ├── app.py            # Flask API (auth, CRUD, uploads, AI chat)
│   ├── database.py       # SQLite schema + sample college data
│   ├── rag.py            # PDF/TXT reading, chunking, BM25 retrieval
│   ├── requirements.txt
│   ├── .env.example
│   └── uploads/          # uploaded documents are stored here
└── frontend/
    ├── package.json, vite.config.js, tailwind.config.js, postcss.config.js, index.html
    └── src/
        ├── main.jsx, App.jsx, index.css, api.js
        ├── components/ui.jsx
        └── pages/ Dashboard, Chat, Notices, Timetable, Faculty, Materials, Admin (.jsx)
```

## Setup (you need Python 3.10+ and Node.js 18+)

### 1) Backend
```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # Mac/Linux: cp .env.example .env
# open .env and paste your ANTHROPIC_API_KEY (from console.anthropic.com)
python app.py
```
Backend runs on http://localhost:5000. The database and sample data are created automatically on first start.

### 2) Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Admin login
Username/password come from `backend/.env` (default `admin` / `admin123`). **Change them before deploying.**
Admin panel: add/edit/delete notices, faculty, timetable, departments, college info, and upload documents.

## How the AI works
1. Admin uploads PDF/TXT -> text is extracted and split into chunks stored in SQLite.
2. For each question, the backend ranks chunks + notices/faculty/timetable/college info (BM25).
3. Only the best matches are sent to Claude with strict rules: answer from sources only, cite [1][2], otherwise tell the student to contact the administration.
4. The API key stays on the server (never in frontend code).

## Notes
- Scanned (image-only) PDFs have no text; use text-based PDFs.
- To reset all data, delete `backend/campusmate.db` and the files in `backend/uploads/`, then restart.
- Set `ANTHROPIC_MODEL` in `.env` to change the Claude model.
- The sample data is fictional - replace it from the Admin panel.
