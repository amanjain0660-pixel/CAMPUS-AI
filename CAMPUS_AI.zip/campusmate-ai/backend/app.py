import os
import uuid
from datetime import date
from functools import wraps

import anthropic
from dotenv import load_dotenv
from flask import Flask, abort, jsonify, request, send_from_directory
from flask_cors import CORS
from itsdangerous import BadSignature, URLSafeTimedSerializer
from werkzeug.security import check_password_hash

load_dotenv()

from database import UPLOAD_DIR, get_db, index_file, init_db  # noqa: E402
from rag import rank  # noqa: E402

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
CORS(app)

signer = URLSafeTimedSerializer(os.getenv("SECRET_KEY", "dev-secret-change-me"))
MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")
init_db(os.getenv("ADMIN_USERNAME", "admin"), os.getenv("ADMIN_PASSWORD", "admin123"))

DAY_ORDER = "CASE day WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3 WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 ELSE 7 END"
RESOURCES = {
    "notices": (["title", "content", "category", "notice_date"], "ORDER BY notice_date DESC, id DESC"),
    "faculty": (["name", "department", "designation", "email", "phone"], "ORDER BY department, name"),
    "timetable": (
        ["department", "semester", "day", "start_time", "end_time", "subject", "room", "faculty"],
        f"ORDER BY department, CAST(semester AS INTEGER), {DAY_ORDER}, start_time",
    ),
    "departments": (["name", "courses", "description"], "ORDER BY name"),
}
COLLEGE_FIELDS = ["name", "address", "phone", "email", "website", "opening_time", "closing_time", "admission_info"]
DOC_CATEGORIES = ["General", "Notes", "Syllabus", "Previous Papers"]


def rows(db, sql, args=()):
    return [dict(r) for r in db.execute(sql, args).fetchall()]


def admin_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        try:
            signer.loads(token, max_age=12 * 3600)
        except BadSignature:
            return jsonify(error="Unauthorized"), 401
        return fn(*a, **kw)

    return wrapper


def error(msg, code=400):
    return jsonify(error=msg), code


# ---------------- Auth ----------------
@app.post("/api/admin/login")
def login():
    data = request.get_json(silent=True) or {}
    db = get_db()
    row = db.execute("SELECT * FROM admins WHERE username=?", (data.get("username", ""),)).fetchone()
    db.close()
    if not row or not check_password_hash(row["password_hash"], data.get("password", "")):
        return error("Invalid username or password", 401)
    return jsonify(token=signer.dumps({"u": row["username"]}))


# ---------------- College info ----------------
@app.get("/api/college")
def get_college():
    db = get_db()
    info = rows(db, "SELECT * FROM college_info WHERE id=1")
    db.close()
    return jsonify(info[0] if info else {})


@app.put("/api/college")
@admin_required
def update_college():
    data = request.get_json(silent=True) or {}
    sets = [f for f in COLLEGE_FIELDS if f in data]
    if sets:
        db = get_db()
        db.execute(f"UPDATE college_info SET {','.join(f + '=?' for f in sets)} WHERE id=1", [str(data[f]) for f in sets])
        db.commit()
        db.close()
    return jsonify(ok=True)


# ---------------- Generic CRUD: notices / faculty / timetable / departments ----------------
@app.get("/api/<res>")
def list_res(res):
    if res not in RESOURCES:
        abort(404)
    db = get_db()
    data = rows(db, f"SELECT * FROM {res} {RESOURCES[res][1]}")
    db.close()
    return jsonify(data)


@app.post("/api/<res>")
@admin_required
def create_res(res):
    if res not in RESOURCES:
        abort(404)
    fields = RESOURCES[res][0]
    data = request.get_json(silent=True) or {}
    vals = {f: str(data.get(f) or "").strip() for f in fields}
    if not vals[fields[0]]:
        return error(f"'{fields[0]}' is required")
    if res == "notices" and not vals["notice_date"]:
        vals["notice_date"] = date.today().isoformat()
    db = get_db()
    cur = db.execute(f"INSERT INTO {res}({','.join(fields)}) VALUES({','.join(['?'] * len(fields))})", list(vals.values()))
    db.commit()
    db.close()
    return jsonify(id=cur.lastrowid), 201


@app.put("/api/<res>/<int:item_id>")
@admin_required
def update_res(res, item_id):
    if res not in RESOURCES:
        abort(404)
    data = request.get_json(silent=True) or {}
    sets = [f for f in RESOURCES[res][0] if f in data]
    if not sets:
        return error("Nothing to update")
    db = get_db()
    db.execute(f"UPDATE {res} SET {','.join(f + '=?' for f in sets)} WHERE id=?", [str(data[f]).strip() for f in sets] + [item_id])
    db.commit()
    db.close()
    return jsonify(ok=True)


@app.delete("/api/<res>/<int:item_id>")
@admin_required
def delete_res(res, item_id):
    if res not in RESOURCES:
        abort(404)
    db = get_db()
    db.execute(f"DELETE FROM {res} WHERE id=?", (item_id,))
    db.commit()
    db.close()
    return jsonify(ok=True)


# ---------------- Documents (study materials + AI knowledge base) ----------------
@app.get("/api/documents")
def list_documents():
    db = get_db()
    data = rows(db, "SELECT id,title,category,department,semester,original_name,uploaded_at FROM documents ORDER BY id DESC")
    db.close()
    return jsonify(data)


@app.post("/api/documents")
@admin_required
def upload_document():
    f = request.files.get("file")
    if not f or not f.filename:
        return error("Please choose a file")
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ("pdf", "txt", "md"):
        return error("Only PDF, TXT or MD files are supported")
    category = request.form.get("category", "General")
    if category not in DOC_CATEGORIES:
        category = "General"
    stored = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(UPLOAD_DIR, stored)
    f.save(path)
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO documents(title,category,department,semester,filename,original_name,uploaded_at) VALUES(?,?,?,?,?,?,?)",
            (
                request.form.get("title", "").strip() or f.filename,
                category,
                request.form.get("department", "All") or "All",
                request.form.get("semester", ""),
                stored,
                f.filename,
                date.today().isoformat(),
            ),
        )
        n = index_file(db, cur.lastrowid, path)
        db.commit()
    except Exception as exc:  # unreadable / corrupt file
        db.close()
        os.remove(path)
        return error(f"Could not read this file: {exc}")
    db.close()
    warning = "" if n else "Uploaded, but no readable text was found (scanned PDF?). The AI cannot use it."
    return jsonify(id=cur.lastrowid, chunks=n, warning=warning), 201


@app.get("/api/documents/<int:doc_id>/download")
def download_document(doc_id):
    db = get_db()
    row = db.execute("SELECT filename, original_name FROM documents WHERE id=?", (doc_id,)).fetchone()
    db.close()
    if not row:
        abort(404)
    return send_from_directory(UPLOAD_DIR, row["filename"], download_name=row["original_name"])


@app.delete("/api/documents/<int:doc_id>")
@admin_required
def delete_document(doc_id):
    db = get_db()
    row = db.execute("SELECT filename FROM documents WHERE id=?", (doc_id,)).fetchone()
    if row:
        db.execute("DELETE FROM documents WHERE id=?", (doc_id,))  # chunks cascade
        db.commit()
        try:
            os.remove(os.path.join(UPLOAD_DIR, row["filename"]))
        except OSError:
            pass
    db.close()
    return jsonify(ok=True)


# ---------------- AI chat ----------------
SYSTEM_PROMPT = """You are CampusMate AI, the official information assistant for the college described in the sources.
Rules:
1. Answer ONLY from the numbered sources given in the user's message. They are the single source of truth.
2. Never invent or guess college facts (dates, fees, names, phone numbers, timings, rules).
3. If the sources do not contain the answer, say you do not have that information and ask the student to contact the college administration (include contact details from the sources if available).
4. Cite sources inline using their numbers, like [1] or [2][3], right after the facts they support.
5. Be friendly, concise and clear. Plain text only - no markdown headings or bold. Use "-" for lists.
6. For greetings or small talk, reply briefly and offer help with college topics."""


def build_candidates(db):
    c = []
    info = db.execute("SELECT * FROM college_info WHERE id=1").fetchone()
    if info:
        c.append({"source": "College Information", "text": (
            f"College: {info['name']}. Address: {info['address']}. Phone: {info['phone']}. Email: {info['email']}. "
            f"Website: {info['website']}. Opening time: {info['opening_time']}. Closing time: {info['closing_time']}. "
            f"Admission information: {info['admission_info']}")})
    for d in rows(db, "SELECT * FROM departments"):
        c.append({"source": f"Department: {d['name']}", "text": f"Department {d['name']}. Courses: {d['courses']}. {d['description']}"})
    for n in rows(db, "SELECT * FROM notices ORDER BY notice_date DESC"):
        c.append({"source": f"Notice: {n['title']} ({n['notice_date']})", "text": f"{n['category']} notice dated {n['notice_date']}: {n['title']}. {n['content']}"})
    for f in rows(db, "SELECT * FROM faculty"):
        c.append({"source": f"Faculty: {f['name']}", "text": f"{f['name']} is {f['designation']} in {f['department']}. Email: {f['email']}. Phone: {f['phone']}."})
    groups = {}
    for t in rows(db, f"SELECT * FROM timetable ORDER BY {DAY_ORDER}, start_time"):
        groups.setdefault((t["department"], t["semester"]), []).append(
            f"{t['day']} {t['start_time']}-{t['end_time']}: {t['subject']} ({t['room']}, {t['faculty']})")
    for (dept, sem), lines in groups.items():
        c.append({"source": f"Timetable: {dept}, Semester {sem}", "text": f"Timetable for {dept} semester {sem}. " + "; ".join(lines)})
    for ch in rows(db, "SELECT chunks.page, chunks.text, documents.id AS doc_id, documents.title FROM chunks JOIN documents ON documents.id=chunks.doc_id"):
        c.append({"source": f"{ch['title']}, page {ch['page']}", "text": ch["text"], "doc_id": ch["doc_id"]})
    return c


@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    if not message:
        return error("Message is empty")
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key or api_key.startswith("your-"):
        return error("The server has no ANTHROPIC_API_KEY configured. Add it to backend/.env and restart.", 503)

    history = [
        {"role": m["role"], "content": m["content"]}
        for m in (data.get("history") or [])[-8:]
        if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str) and m["content"].strip()
    ]
    while history and history[0]["role"] != "user":
        history.pop(0)
    last_user = next((m["content"] for m in reversed(history) if m["role"] == "user"), "")

    db = get_db()
    candidates = build_candidates(db)
    db.close()
    hits = rank(f"{last_user} {message}", candidates, k=6)
    context = "\n\n".join(f"[{i + 1}] ({h['source']})\n{h['text']}" for i, h in enumerate(hits)) or "(no relevant sources found)"
    user_content = f"<sources>\n{context}\n</sources>\n\nStudent question: {message}"

    try:
        client = anthropic.Anthropic(api_key=api_key)
        resp = client.messages.create(
            model=MODEL, max_tokens=800, system=SYSTEM_PROMPT,
            messages=history + [{"role": "user", "content": user_content}],
        )
    except anthropic.APIError as exc:
        return error(f"AI service error: {getattr(exc, 'message', str(exc))}", 502)

    answer = "".join(b.text for b in resp.content if b.type == "text").strip()
    sources = [
        {"n": i + 1, "source": h["source"], "doc_id": h.get("doc_id")}
        for i, h in enumerate(hits) if f"[{i + 1}]" in answer
    ]
    return jsonify(answer=answer, sources=sources)


@app.get("/api/health")
def health():
    return jsonify(status="ok")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
