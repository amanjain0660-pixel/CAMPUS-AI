"""Document reading + simple BM25-style retrieval (no external vector DB needed)."""
import math
import re
from collections import Counter

from pypdf import PdfReader

STOP = set(
    "a an the is are was were of to in on for and or at by with from what when where who how "
    "do does can i me my you your it this that be as about tell please".split()
)


def tokens(text):
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP]


def extract_pages(path):
    """Return [(page_number, text)] for a PDF / TXT / MD file."""
    if path.lower().endswith(".pdf"):
        reader = PdfReader(path)
        return [(i + 1, p.extract_text() or "") for i, p in enumerate(reader.pages)]
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return [(1, f.read())]


def chunk_text(text, size=900, overlap=150):
    text = re.sub(r"\s+", " ", text).strip()
    out, i = [], 0
    while i < len(text):
        out.append(text[i : i + size])
        i += size - overlap
    return out


def rank(query, candidates, k=6):
    """Rank candidate dicts ({'source','text',...}) against the query using BM25."""
    q = set(tokens(query))
    if not q or not candidates:
        return []
    docs = [Counter(tokens(c["text"] + " " + c["source"])) for c in candidates]
    n = len(docs)
    avg = (sum(sum(d.values()) for d in docs) / n) or 1
    df = Counter()
    for d in docs:
        for t in d:
            df[t] += 1
    scored = []
    for c, d in zip(candidates, docs):
        length, score = sum(d.values()), 0.0
        for t in q:
            f = d.get(t, 0)
            if f:
                idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                score += idf * f * 2.2 / (f + 1.2 * (0.25 + 0.75 * length / avg))
        if score > 0:
            scored.append((score, c))
    scored.sort(key=lambda x: -x[0])
    return [c for _, c in scored[:k]]
