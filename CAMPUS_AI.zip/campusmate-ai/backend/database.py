import os
import sqlite3
from datetime import date, timedelta

from werkzeug.security import generate_password_hash

from rag import chunk_text, extract_pages

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "campusmate.db")
UPLOAD_DIR = os.path.join(BASE, "uploads")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT);
CREATE TABLE IF NOT EXISTS college_info(
  id INTEGER PRIMARY KEY CHECK(id=1), name TEXT, address TEXT, phone TEXT, email TEXT, website TEXT,
  opening_time TEXT, closing_time TEXT, admission_info TEXT);
CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, courses TEXT, description TEXT);
CREATE TABLE IF NOT EXISTS notices(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT, category TEXT, notice_date TEXT);
CREATE TABLE IF NOT EXISTS faculty(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, department TEXT, designation TEXT, email TEXT, phone TEXT);
CREATE TABLE IF NOT EXISTS timetable(
  id INTEGER PRIMARY KEY AUTOINCREMENT, department TEXT, semester TEXT, day TEXT,
  start_time TEXT, end_time TEXT, subject TEXT, room TEXT, faculty TEXT);
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, category TEXT, department TEXT, semester TEXT,
  filename TEXT, original_name TEXT, uploaded_at TEXT);
CREATE TABLE IF NOT EXISTS chunks(
  id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id INTEGER REFERENCES documents(id) ON DELETE CASCADE,
  page INTEGER, text TEXT);
"""


def index_file(db, doc_id, path):
    """Extract text from a file and store it as searchable chunks. Returns chunk count."""
    n = 0
    for page, text in extract_pages(path):
        for ch in chunk_text(text):
            db.execute("INSERT INTO chunks(doc_id,page,text) VALUES(?,?,?)", (doc_id, page, ch))
            n += 1
    return n


HANDBOOK = """Sunrise Institute of Technology - Student Handbook (SAMPLE)

Attendance: Students must maintain at least 75% attendance in each subject to be eligible for end-semester examinations. Students with 65% to 74% attendance may apply for condonation with a valid medical certificate and a fee of Rs. 500 per subject.

Library: The central library is open Monday to Saturday from 8:30 AM to 7:00 PM. Students can borrow up to 4 books for 14 days using their ID card. A late fine of Rs. 2 per day per book applies.

Examinations: Internal assessments are held twice per semester. End-semester exams are conducted in December (odd semesters) and May (even semesters). Students must carry their ID card and admit card to the exam hall. Mobile phones are strictly prohibited.

Fees: Tuition fee for B.Tech is Rs. 85,000 per year and for MBA is Rs. 95,000 per year. Fees are paid in two installments, due on 15 July and 15 January. Late payment attracts a fine of Rs. 100 per day.

Scholarships: Merit scholarships of 25% tuition waiver are given to students scoring above 90% in the previous qualifying exam. Applications are submitted to the Accounts Office.

Hostel: Separate hostels for boys and girls are available. Hostel fee is Rs. 60,000 per year including mess. Hostel gate closes at 9:00 PM.

Anti-ragging: Ragging is a punishable offence. Report incidents to the Anti-Ragging Committee at antiragging@sunrise.example or call the 24x7 helpline 1800-000-0000.
"""


def seed(db):
    db.execute(
        "INSERT INTO college_info VALUES(1,?,?,?,?,?,?,?,?)",
        (
            "Sunrise Institute of Technology",
            "12 Knowledge Park Road, Sample City, State - 000000, India",
            "+91 00000 00000", "info@sunrise.example", "https://sunrise.example",
            "9:00 AM", "4:30 PM (Monday to Saturday)",
            "Admissions open every year from May 1 to July 15. B.Tech admission is based on entrance exam rank "
            "plus counselling. MBA admission requires a valid CAT/MAT score and a personal interview. "
            "Documents required: 10th and 12th marksheets, transfer certificate, ID proof, 4 passport photos. "
            "Contact the Admission Office: admissions@sunrise.example.",
        ),
    )
    depts = [
        ("Computer Science & Engineering", "B.Tech CSE, M.Tech CSE", "Programming, AI, data science, cloud computing and cyber security."),
        ("Electronics & Communication", "B.Tech ECE", "VLSI, embedded systems, communication and IoT."),
        ("Mechanical Engineering", "B.Tech ME", "Design, thermal engineering, manufacturing and robotics."),
        ("Management Studies", "MBA, BBA", "Marketing, finance, HR and business analytics."),
    ]
    db.executemany("INSERT INTO departments(name,courses,description) VALUES(?,?,?)", depts)
    t = date.today()
    notices = [
        ("Mid-Semester Examination Schedule", "Mid-semester exams for all B.Tech students begin on " + (t + timedelta(days=12)).strftime("%d %b %Y") + ". Detailed datesheet is available at the Examination Cell.", "Exam", t),
        ("Diwali Holiday", "The college will remain closed from " + (t + timedelta(days=20)).strftime("%d %b") + " to " + (t + timedelta(days=24)).strftime("%d %b %Y") + " for Diwali.", "Holiday", t - timedelta(days=1)),
        ("Annual Tech Fest - Innovera 2026", "Registrations are open for Innovera. Events include hackathon, robo-race and paper presentation. Register at the Student Activity Centre.", "Event", t - timedelta(days=2)),
        ("Scholarship Applications Open", "Merit scholarship forms are available at the Accounts Office. Last date is " + (t + timedelta(days=15)).strftime("%d %b %Y") + ".", "General", t - timedelta(days=4)),
    ]
    db.executemany("INSERT INTO notices(title,content,category,notice_date) VALUES(?,?,?,?)", [(a, b, c, d.isoformat()) for a, b, c, d in notices])
    faculty = [
        ("Dr. Rajesh Verma", "Computer Science & Engineering", "Professor & Head of Department", "rajesh.verma@sunrise.example", "+91 00000 10001"),
        ("Dr. Anita Sharma", "Computer Science & Engineering", "Associate Professor", "anita.sharma@sunrise.example", "+91 00000 10002"),
        ("Mr. Vikram Singh", "Electronics & Communication", "Assistant Professor", "vikram.singh@sunrise.example", "+91 00000 10003"),
        ("Dr. Meera Iyer", "Electronics & Communication", "Professor & Head of Department", "meera.iyer@sunrise.example", "+91 00000 10004"),
        ("Dr. Suresh Patel", "Mechanical Engineering", "Professor & Head of Department", "suresh.patel@sunrise.example", "+91 00000 10005"),
        ("Ms. Neha Gupta", "Management Studies", "Assistant Professor", "neha.gupta@sunrise.example", "+91 00000 10006"),
    ]
    db.executemany("INSERT INTO faculty(name,department,designation,email,phone) VALUES(?,?,?,?,?)", faculty)
    cse, ece = "Computer Science & Engineering", "Electronics & Communication"
    tt = [
        (cse, "3", "Monday", "09:00", "10:00", "Data Structures", "Room 101", "Dr. Anita Sharma"),
        (cse, "3", "Monday", "10:00", "11:00", "Discrete Mathematics", "Room 101", "Dr. Rajesh Verma"),
        (cse, "3", "Tuesday", "09:00", "11:00", "DS Lab", "Lab 2", "Dr. Anita Sharma"),
        (cse, "3", "Wednesday", "10:00", "11:00", "Computer Organization", "Room 102", "Dr. Rajesh Verma"),
        (cse, "3", "Thursday", "09:00", "10:00", "Data Structures", "Room 101", "Dr. Anita Sharma"),
        (cse, "3", "Friday", "11:00", "12:00", "Discrete Mathematics", "Room 101", "Dr. Rajesh Verma"),
        (ece, "3", "Monday", "09:00", "10:00", "Analog Circuits", "Room 201", "Mr. Vikram Singh"),
        (ece, "3", "Tuesday", "10:00", "11:00", "Signals & Systems", "Room 201", "Dr. Meera Iyer"),
        (ece, "3", "Thursday", "09:00", "11:00", "Circuits Lab", "Lab 5", "Mr. Vikram Singh"),
    ]
    db.executemany("INSERT INTO timetable(department,semester,day,start_time,end_time,subject,room,faculty) VALUES(?,?,?,?,?,?,?,?)", tt)
    stored = "sample-handbook.txt"
    path = os.path.join(UPLOAD_DIR, stored)
    with open(path, "w", encoding="utf-8") as f:
        f.write(HANDBOOK)
    cur = db.execute(
        "INSERT INTO documents(title,category,department,semester,filename,original_name,uploaded_at) VALUES(?,?,?,?,?,?,?)",
        ("Student Handbook (Sample)", "General", "All", "", stored, "student-handbook.txt", date.today().isoformat()),
    )
    index_file(db, cur.lastrowid, path)


def init_db(admin_user, admin_pass):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    db = get_db()
    db.executescript(SCHEMA)
    db.execute("DELETE FROM admins WHERE username!=?", (admin_user,))
    db.execute(
        "INSERT INTO admins(username,password_hash) VALUES(?,?) "
        "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash",
        (admin_user, generate_password_hash(admin_pass)),
    )
    if not db.execute("SELECT 1 FROM college_info").fetchone():
        seed(db)
    db.commit()
    db.close()
